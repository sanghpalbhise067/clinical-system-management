from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_mysqldb import MySQL
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from datetime import date

app = Flask(__name__)
app.secret_key = 'your_super_secret_secure_key'

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'root'
app.config['MYSQL_DB'] = 'clinic_dbase'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'

mysql = MySQL(app)

# --- Security & RBAC Decorators ---
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash("Please log in first.", "danger")
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def role_required(role):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if session.get('role') != role:
                flash("Unauthorized access.", "danger")
                return redirect(url_for('login'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# --- Authentication Routes ---
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        full_name = request.form['full_name']
        username = request.form['username']
        email = request.form['email']
        password = generate_password_hash(request.form['password'])
        role = request.form['role'] # 'doctor' or 'receptionist'

        cur = mysql.connection.cursor()
        try:
            cur.execute(
                "INSERT INTO users (full_name, username, email, password_hash, role) VALUES (%s, %s, %s, %s, %s)",
                (full_name, username, email, password, role)
            )
            mysql.connection.commit()
            flash("Registration successful! Please login.", "success")
            return redirect(url_for('login'))
        except Exception as e:
            mysql.connection.rollback()
            flash("User registration failed. Username or email may already exist.", "danger")
        finally:
            cur.close()
            
    return render_template('register.html')

@app.route('/', methods=['GET', 'POST'])
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE username = %s", (username,))
        user = cur.fetchone()
        cur.close()

        if user and check_password_hash(user['password_hash'], password):
            session['user_id'] = user['user_id']
            session['username'] = user['username']
            session['role'] = user['role']
            session['full_name'] = user['full_name']

            if user['role'] == 'doctor':
                return redirect(url_for('doctor_dashboard'))
            else:
                return redirect(url_for('receptionist_dashboard'))
        else:
            flash("Invalid credentials.", "danger")

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash("Logged out successfully.", "info")
    return redirect(url_for('login'))

# --- Receptionist Dashboard & Registration ---
@app.route('/receptionist/dashboard', methods=['GET', 'POST'])
@login_required
@role_required('receptionist')
def receptionist_dashboard():
    cur = mysql.connection.cursor()
    
    if request.method == 'POST':
        # Form inputs
        serial_no = request.form['serial_no']
        full_name = request.form['full_name']
        age = request.form['age']
        gender = request.form['gender']
        contact_no = request.form['contact_no']
        address = request.form['address']
        spouse_father = request.form['spouse_father']
        prev_children = request.form['prev_children']
        referred_by = request.form['referred_by']
        ucg_type = request.form['ucg_type']
        payment_mode = request.form['payment_mode'] # 'Cash' or 'Online'
        total_amount = request.form['total_amount']
        today_date = date.today()

        try:
            # 1. Insert Patient
            cur.execute(
                "INSERT INTO patients (full_name, age, gender, contact_no, detailed_address) VALUES (%s, %s, %s, %s, %s)",
                (full_name, age, gender, contact_no, address)
            )
            patient_id = cur.lastrowid

            # 2. Insert UCG Details
            cur.execute(
                "INSERT INTO ucg_details (patient_id, spouse_or_father_name, previous_children_details) VALUES (%s, %s, %s)",
                (patient_id, spouse_father, prev_children)
            )

            # 3. Insert Appointment
            cur.execute(
                "INSERT INTO appointments (serial_no, patient_id, referred_by, ucg_type, visit_date, created_by_receptionist_id) VALUES (%s, %s, %s, %s, %s, %s)",
                (serial_no, patient_id, referred_by, ucg_type, today_date, session['user_id'])
            )
            appointment_id = cur.lastrowid

            # 4. Insert Payment
            cur.execute(
                "INSERT INTO payments (appointment_id, total_amount, payment_mode) VALUES (%s, %s, %s)",
                (appointment_id, total_amount, payment_mode)
            )

            mysql.connection.commit()
            flash("Patient registered successfully!", "success")
        except Exception as e:
            mysql.connection.rollback()
            flash(f"Error registering patient: {str(e)}", "danger")

    # Fetch today's registrations for receptionist view
    cur.execute("""
        SELECT a.serial_no, p.full_name, p.contact_no, a.ucg_type, pay.total_amount, pay.payment_mode
        FROM appointments a
        JOIN patients p ON a.patient_id = p.patient_id
        JOIN payments pay ON a.appointment_id = pay.appointment_id
        WHERE a.visit_date = CURDATE()
        ORDER BY a.appointment_id DESC
    """)
    today_registrations = cur.fetchall()
    cur.close()

    return render_template('receptionist_dashboard.html', registrations=today_registrations)

# --- Doctor Dashboard ---
@app.route('/doctor/dashboard')
@login_required
@role_required('doctor')
def doctor_dashboard():
    cur = mysql.connection.cursor()

    # 1. Today's Patients
    cur.execute("""
        SELECT a.serial_no, p.full_name, p.age, p.gender, p.contact_no, u.spouse_or_father_name, 
               u.previous_children_details, a.referred_by, a.ucg_type, pay.total_amount, pay.payment_mode
        FROM appointments a
        JOIN patients p ON a.patient_id = p.patient_id
        LEFT JOIN ucg_details u ON p.patient_id = u.patient_id
        JOIN payments pay ON a.appointment_id = pay.appointment_id
        WHERE a.visit_date = CURDATE()
        ORDER BY a.appointment_id ASC
    """)
    today_patients = cur.fetchall()

    # 2. Previous Patients
    cur.execute("""
        SELECT a.serial_no, p.full_name, a.visit_date, a.ucg_type, pay.total_amount
        FROM appointments a
        JOIN patients p ON a.patient_id = p.patient_id
        JOIN payments pay ON a.appointment_id = pay.appointment_id
        WHERE a.visit_date < CURDATE()
        ORDER BY a.visit_date DESC LIMIT 50
    """)
    previous_patients = cur.fetchall()

    # 3. Payment Summary / History
    cur.execute("""
        SELECT 
            SUM(CASE WHEN pay.payment_mode = 'Cash' AND a.visit_date = CURDATE() THEN pay.total_amount ELSE 0 END) AS today_cash,
            SUM(CASE WHEN pay.payment_mode = 'Online' AND a.visit_date = CURDATE() THEN pay.total_amount ELSE 0 END) AS today_online,
            SUM(CASE WHEN a.visit_date = CURDATE() THEN pay.total_amount ELSE 0 END) AS today_total,
            SUM(pay.total_amount) AS grand_total
        FROM payments pay
        JOIN appointments a ON pay.appointment_id = a.appointment_id
    """)
    payment_summary = cur.fetchone()
    cur.close()

    return render_template('doctor_dashboard.html', 
                           today_patients=today_patients, 
                           previous_patients=previous_patients, 
                           summary=payment_summary)

if __name__ == '__main__':
    app.run(debug=True)